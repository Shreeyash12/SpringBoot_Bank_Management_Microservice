package com.tcs.employee;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.tcs.employee.dao.EmployeeRepository;
import com.tcs.employee.model.Employee;

@Configuration
public class DataSeeder {


    @Bean
    public CommandLineRunner loadEmployeeData(EmployeeRepository employeeRepository) {
        return args -> {
            Employee employee1 = new Employee( "Alice", "Williams", "alice.williams@example.com", "1988-04-15", "IT", "123 Elm Street");
            Employee employee2 = new Employee( "Bob", "Brown", "bob.brown@example.com", "1991-09-30", "HR", "456 Oak Avenue");
            Employee employee3 = new Employee( "Charlie", "Davis", "charlie.davis@example.com", "1985-02-05", "Finance", "789 Pine Road");

            // Save them into the database
            employeeRepository.save(employee1);
            employeeRepository.save(employee2);
            employeeRepository.save(employee3);

            System.out.println("Employee seed data loaded.");
        };
    }
}

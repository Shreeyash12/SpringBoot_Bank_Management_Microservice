package com.tcs.customer.service;

import java.util.List;

import com.tcs.customer.model.Customer;

public interface CustomeService {
	 Customer createCustomer(Customer customer);
	    Customer getCustomerById(int id);
	    List<Customer> getAllCustomer();
	    Customer updateCustomer(int id,Customer customer);
	    void deleteCustomer(int id);
}

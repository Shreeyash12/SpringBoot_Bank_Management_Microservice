package com.tcs.customer.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.customer.dao.CustomerRepository;
import com.tcs.customer.exception.CustomerNotFoundException;
import com.tcs.customer.model.Customer;


import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomeService {
    @Autowired
    private CustomerRepository customerRepository;

  
	@Override
	public Customer createCustomer(Customer customer) {

		  return customerRepository.save(customer);	}

	@Override
	public Customer getCustomerById(int id) {

		  return customerRepository.findById(id).orElseThrow(()-> new CustomerNotFoundException("Customer not found"));
	}

	@Override
	public Customer updateCustomer(int id, Customer customer) {
		 Optional<Customer> existingCustomer = customerRepository.findById(id);
	        if (existingCustomer.isPresent()) {
	        	Customer updatedCustomer = existingCustomer.get();
	        	updatedCustomer.setFirstName(customer.getFirstName());
	        	updatedCustomer.setLastName(customer.getLastName());
	        	updatedCustomer.setEmail(customer.getEmail());
	        	updatedCustomer.setDateOfBirth(customer.getDateOfBirth());
	        	updatedCustomer.setAddharNo(customer.getAddharNo());
	        	updatedCustomer.setPanNo(customer.getPanNo());

	            return customerRepository.save(updatedCustomer);
	        }else {
	            throw new CustomerNotFoundException("Employee not found");
	        }
	}

	@Override
	public List<Customer> getAllCustomer() {
		 return customerRepository.findAll();
	}

	@Override
	public void deleteCustomer(int id) {
		 if (!customerRepository.existsById(id)) {
	            throw new CustomerNotFoundException("Customer not found with ID: " + id);
	        }
	        customerRepository.deleteById(id);
		
	}
}


package com.tcs.customer.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int ssnId;
    private String firstName;
    private String lastName;
    private String email;
    private String dateOfBirth;
    private long bankAccountNo;
    private long addharNo;
    private String panNo;

    public Customer() {
    }
    public Customer(int id, int ssnId, String firstName, String lastName, String email, String dateOfBirth, long bankAccountNo, long addharNo, String panNo) {
        this.id = id;
        this.ssnId = ssnId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.bankAccountNo = bankAccountNo;
        this.addharNo = addharNo;
        this.panNo = panNo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSsnId() {
        return ssnId;
    }

    public void setSsnId(int ssnId) {
        this.ssnId = ssnId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public long getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(long bankAccountNo) {
        this.bankAccountNo = bankAccountNo;
    }

    public long getAddharNo() {
        return addharNo;
    }

    public void setAddharNo(long addharNo) {
        this.addharNo = addharNo;
    }

    public String getPanNo() {
        return panNo;
    }

    public void setPanNo(String panNo) {
        this.panNo = panNo;
    }
	


}


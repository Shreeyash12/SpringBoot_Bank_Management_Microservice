package com.tcs.customer;


import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.tcs.customer.dao.CustomerRepository;
import com.tcs.customer.model.Customer;

@Configuration
public class DataSeeder {

    @Bean
    public CommandLineRunner loadCustomerData(CustomerRepository customerRepository) {
        return args -> {
            Customer customer1 = new Customer(0, 12345, "John", "Doe", "john.doe@example.com", "1990-05-12", 1010101L, 123456789012L, "ABCDE1234F");
            Customer customer2 = new Customer(0, 23456, "Jane", "Smith", "jane.smith@example.com", "1985-07-22", 2020202L, 987654321012L, "XYZAB5678G");
            Customer customer3 = new Customer(0, 34567, "Mark", "Johnson", "mark.johnson@example.com", "1992-03-10", 3030303L, 567890123456L, "PQRST9012H");

            // Save them into the database
            customerRepository.save(customer1);
            customerRepository.save(customer2);
            customerRepository.save(customer3);

            System.out.println("Customer seed data loaded.");
        };
    }



}
